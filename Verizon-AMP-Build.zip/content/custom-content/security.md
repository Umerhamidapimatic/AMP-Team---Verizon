Verizon REST APIs are secured by Client Authentication (Two-Way SSL) and HTTP Basic Authentication. Verizon 
security recommends the 2-way SSL for APIs as it provides the highest level of security for APIs published over the 
Internet. On a Two-way enabled SSL connection both the client and the server communicate on a verified connection. 
The verification is done using certificates to identify the client and ensure that the requestor is trusted.

To enable Two way SSL communication, the client side is required to procure its own set of certificates (private key 
and public key) from a Certifying Authority (like Verisign, DigiCert, GoDaddy etc).The private key must be kept secure 
on the client side and should not be shared. The application on the client side (ServiceNow) should be configured to 
send this private key while initiating the transactions to the Verizon gateway. The public key must be sent by email to 
Verizon to be added to the Trust store on the gateway. 

Please procure a certificate from your company's certificate team or any CA like Verisign, GoDaddy etc. Verizon does 
not accept self-signed certificates. 

Below is operational & technical guidance: 

- Cannot be a self-signed certificate.
- Verizon will accept any certificate issued by a certifying authority like Verisign etc.
- In order to obtain a certificate from CA (Certificate Authority), a CSR (Certificate Signing Request) needs to be submitted to the CA.
- The common name on the issued certificate can be set to any value and does not have to be specific to any host/domain. This certificate will be used only for 'Authentication only' (unlike a standard SSL certificate where common name on the certificate needs to match a host name)
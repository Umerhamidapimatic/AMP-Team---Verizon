Verizon Service Management APIs use open APIs to enable enterprise customers to automate the end-to-end 
delivery of a service that relies on multiple suppliers. Service Management APIs also help customers automate 
how they manage multiple digital supplier relationships. Verizon created, certified, and developed a suite of TM 
Forum Open APIs, enabling enterprise customers to consume multiple interlinked services using code.

The Service Management APIs are enabled via multiple access methods with future plans to include the native 
integration using the ServiceNow platform. This service is a component of Verizon’s Digital Enablement Platform 
that includes a portfolio of service management and service orchestration capabilities that helps customers 
simplify processes, improve productivity and innovate their operations.

From an end-to-end perspective, there are seven APIs, based on which the process is implemented (the official TMF 
document numbers are mentioned below the boxes). The purpose of this document is to provide the details on the API 
TMF645 Check Service Qualification request/response, parameters, sample requests, security requirements and 
URLs for the API implemented on the DEP.

![Into Image](/static/images/introduction-image.png)